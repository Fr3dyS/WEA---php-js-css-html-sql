<!doctype html>
<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
        <script src="jquery-3.0.0.js" type="text/javascript"></script>
        <script src="script.js" type="text/javascript"></script>
        <title>document</title>
    </head>
    <body >
        <div class="container" >
            <input type="file" name="file" id="file">

            <div class="upload-area"  id="uploadfile">
                <h1>premist sobour <br/>nebo<br/>klini a vloz soubor</h1>
            </div>
        </div>

    </body>
</html>